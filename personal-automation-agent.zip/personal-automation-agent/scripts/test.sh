#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:-http://127.0.0.1:18790}"

echo "== health =="
curl -s "$BASE_URL/health" | python3 -m json.tool

echo "\n== status =="
curl -s -X POST "$BASE_URL/command" \
  -H "Content-Type: application/json" \
  -d '{"text":"状态"}' | python3 -m json.tool

echo "\n== check monitors =="
curl -s -X POST "$BASE_URL/command" \
  -H "Content-Type: application/json" \
  -d '{"text":"检查网页"}' | python3 -m json.tool
